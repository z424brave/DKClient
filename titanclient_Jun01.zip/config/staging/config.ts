//export const API_ENDPOINT = 'https://samplenode-env-dk.eu-west-1.elasticbeanstalk.com';
export const API_ENDPOINT = 'https://martian.creative-assembly.com';