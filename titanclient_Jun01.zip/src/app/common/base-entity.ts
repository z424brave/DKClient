export class BaseEntity {
    _id: string;
    created: Date;
    updated: Date;

    constructor() {
    }

}