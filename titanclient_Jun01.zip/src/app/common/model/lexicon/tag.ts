export class Tag {

    _id: string;
    name: string;

    constructor() {
    }

}
