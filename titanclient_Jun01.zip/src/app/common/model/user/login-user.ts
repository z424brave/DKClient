export class LoginUser {

    email: string;
    password: string;

}