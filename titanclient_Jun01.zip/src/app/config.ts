export const API_ENDPOINT = process.env.API;
