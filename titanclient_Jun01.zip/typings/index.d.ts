/// <reference path="modules/es6-promise/index.d.ts" />
/// <reference path="modules/moment/index.d.ts" />
